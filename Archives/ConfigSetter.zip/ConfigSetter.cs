﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace NetChat
{

    
    public partial class ConfigSetter : Form
    {
        public ConfigSetter()
        {
            InitializeComponent();
        }
        [Serializable]
        public class settings
        {
            public string prgInfo { get; set; }
            public string serverIP { get; set; }
        }

        settings localSettings = new settings();
        Form mainMenu = Application.OpenForms["MainMenu"];

        private void ConfigSetter_Load(object sender, EventArgs e)
        {
            loadConf();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(localSettings.GetType());
            using (FileStream writer = File.OpenWrite("NetChat.cfg"))
            {
                serializer.Serialize(writer, localSettings);
            }
            saveButton.Enabled = false;
        }

        private void IPtextBox_TextChanged(object sender, EventArgs e)
        {
            saveButton.Enabled = true;
        }

        private void ConfigSetter_FormClosing(object sender, FormClosingEventArgs e)
        {
            saveConf();
            Close();
        }

        public void loadConf()
        {
            XmlSerializer serializer = new XmlSerializer(localSettings.GetType());
            if (!File.Exists("NetChat.cfg"))
            {
                localSettings.prgInfo = "Version 0.1";
                localSettings.serverIP = "127.0.0.1";
                File.CreateText("NetChat.cfg");
                using (FileStream writer = File.OpenWrite("NetChat.cfg"))
                {
                    serializer.Serialize(writer, localSettings);
                }
            }
            else
            {
                using (StreamReader reader = File.OpenText("NetChat.cfg"))
                {
                    localSettings = (settings)serializer.Deserialize(reader);
                    IPtextBox.Text = localSettings.serverIP;
                }
            }
        }

        public void saveConf()
        {
            if (saveButton.Enabled == true)
            {
                var mbox = MessageBox.Show("Config not Saved! Continue?", "Save Config?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (mbox == DialogResult.Yes)
                {
                    XmlSerializer serializer = new XmlSerializer(localSettings.GetType());
                    using (FileStream writer = File.OpenWrite("NetChat.cfg")) { serializer.Serialize(writer, localSettings); }
                }
            }
        }


    }
    

}
