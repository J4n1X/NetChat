﻿// Decompiled with JetBrains decompiler
// Type: Server.Program
// Assembly: Server, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9FD80A6B-F3BB-4EAD-9AA8-A475AEE1058A
// Assembly location: C:\Users\janic\source\repos\Network Adventues\Server\bin\Debug\Server.exe

using System;

namespace Server
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Server server = new Server();
            Console.Write("Just enter the server-ip, I can't bother:\n");
            string inp = Console.ReadLine();
            Console.Clear();
            server.serverLoader(inp);
        }
    }
}
