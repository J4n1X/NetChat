﻿// Decompiled with JetBrains decompiler
// Type: Server.clientHandler
// Assembly: Server, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9FD80A6B-F3BB-4EAD-9AA8-A475AEE1058A
// Assembly location: C:\Users\janic\source\repos\Network Adventues\Server\bin\Debug\Server.exe

using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{
    public class clientHandler
    {
        public static IDictionary<string, Thread> threadList = (IDictionary<string, Thread>)new Dictionary<string, Thread>();
        private TcpClient clientSocket;
        private string clNo;
        private IDictionary<string, TcpClient> clientsList;

        public void StartClientThread(
          TcpClient inClientSocket,
          string clineNo,
          IDictionary<string, TcpClient> cList)
        {
            this.clientSocket = inClientSocket;
            this.clNo = clineNo;
            this.clientsList = cList;
            Thread thread = new Thread(new ThreadStart(this.ClientCommunicator));
            clientHandler.threadList.Add(this.clNo, thread);
            thread.Start();
        }

        public void ClientCommunicator()
        {
            byte[] numArray = new byte[this.clientSocket.ReceiveBufferSize];
            NetworkStream stream = this.clientSocket.GetStream();
            Server server = new Server();
            while (true)
            {
                try
                {
                    stream.Read(numArray, 0, numArray.Length);
                    string msg = Encoding.ASCII.GetString(numArray).Split('$')[0];
                    Server.Broadcast(msg, this.clNo, true, false);
                    Console.WriteLine("Message from Client - " + this.clNo + " " + msg);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Client " + this.clNo + " Disconnecting");
                    Server.ClientRemove(this.clNo);
                    break;
                }
            }
        }
    }
}
