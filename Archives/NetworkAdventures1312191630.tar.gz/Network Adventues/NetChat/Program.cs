﻿// Decompiled with JetBrains decompiler
// Type: Chat.Program
// Assembly: NetChat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B627D88F-BE10-4C48-8F82-411DE3984AB3
// Assembly location: C:\Users\janic\source\repos\Network Adventues\NetChat\bin\Debug\NetChat.exe

using NetChat;

namespace Chat
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      MainMenu mainMenu = new MainMenu();
      int num = (int) mainMenu.ShowDialog();
      mainMenu.Close();
    }
  }
}
