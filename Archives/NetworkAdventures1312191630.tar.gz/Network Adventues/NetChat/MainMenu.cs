﻿// Decompiled with JetBrains decompiler
// Type: NetChat.MainMenu
// Assembly: NetChat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B627D88F-BE10-4C48-8F82-411DE3984AB3
// Assembly location: C:\Users\janic\source\repos\Network Adventues\NetChat\bin\Debug\NetChat.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace NetChat
{
    public class MainMenu : Form
    {
        private IContainer components = (IContainer)null;
        private ToolStrip toolStrip1;
        private ToolStripSplitButton fileToolStripButton;
        private ToolStripMenuItem setConfigToolStripMenuItem;
        private ToolStripMenuItem loadConfigToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton aboutToolStripButton;
        private Button startServerButton;
        private Button clientStartButton;

        public MainMenu()
        {
            this.InitializeComponent();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
        }

        private void startServerButton_Click(object sender, EventArgs e)
        {

        }

        private void clientStartButton_Click(object sender, EventArgs e)
        {
            int num = (int)new ClientForm().ShowDialog();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && this.components != null)
                this.components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(MainMenu));
            this.toolStrip1 = new ToolStrip();
            this.fileToolStripButton = new ToolStripSplitButton();
            this.setConfigToolStripMenuItem = new ToolStripMenuItem();
            this.loadConfigToolStripMenuItem = new ToolStripMenuItem();
            this.toolStripSeparator1 = new ToolStripSeparator();
            this.aboutToolStripButton = new ToolStripButton();
            this.startServerButton = new Button();
            this.clientStartButton = new Button();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            this.toolStrip1.Items.AddRange(new ToolStripItem[3]
            {
        (ToolStripItem) this.fileToolStripButton,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.aboutToolStripButton
            });
            this.toolStrip1.Location = new Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new Size(245, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.fileToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Text;
            this.fileToolStripButton.DropDownItems.AddRange(new ToolStripItem[2]
            {
        (ToolStripItem) this.setConfigToolStripMenuItem,
        (ToolStripItem) this.loadConfigToolStripMenuItem
            });
            this.fileToolStripButton.Image = (Image)componentResourceManager.GetObject("fileToolStripButton.Image");
            this.fileToolStripButton.ImageTransparentColor = Color.Magenta;
            this.fileToolStripButton.Name = "fileToolStripButton";
            this.fileToolStripButton.Size = new Size(50, 22);
            this.fileToolStripButton.Text = "Datei";
            this.setConfigToolStripMenuItem.Name = "setConfigToolStripMenuItem";
            this.setConfigToolStripMenuItem.Size = new Size(139, 22);
            this.setConfigToolStripMenuItem.Text = "Set Config";
            this.loadConfigToolStripMenuItem.Name = "loadConfigToolStripMenuItem";
            this.loadConfigToolStripMenuItem.Size = new Size(139, 22);
            this.loadConfigToolStripMenuItem.Text = "Load Config";
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new Size(6, 25);
            this.aboutToolStripButton.DisplayStyle = ToolStripItemDisplayStyle.Text;
            this.aboutToolStripButton.Image = (Image)componentResourceManager.GetObject("aboutToolStripButton.Image");
            this.aboutToolStripButton.ImageTransparentColor = Color.Magenta;
            this.aboutToolStripButton.Name = "aboutToolStripButton";
            this.aboutToolStripButton.Size = new Size(44, 22);
            this.aboutToolStripButton.Text = "About";
            this.startServerButton.Location = new Point(13, 37);
            this.startServerButton.Name = "startServerButton";
            this.startServerButton.Size = new Size(220, 64);
            this.startServerButton.TabIndex = 1;
            this.startServerButton.Text = "Start Server";
            this.startServerButton.UseVisualStyleBackColor = true;
            this.startServerButton.Click += new EventHandler(this.startServerButton_Click);
            this.clientStartButton.Location = new Point(13, 107);
            this.clientStartButton.Name = "clientStartButton";
            this.clientStartButton.Size = new Size(220, 64);
            this.clientStartButton.TabIndex = 2;
            this.clientStartButton.Text = "Start Client";
            this.clientStartButton.UseVisualStyleBackColor = true;
            this.clientStartButton.Click += new EventHandler(this.clientStartButton_Click);
            this.AutoScaleDimensions = new SizeF(6f, 13f);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(245, 183);
            this.Controls.Add((Control)this.clientStartButton);
            this.Controls.Add((Control)this.startServerButton);
            this.Controls.Add((Control)this.toolStrip1);
            this.Name = nameof(MainMenu);
            this.Text = "Net Chat";
            this.Load += new EventHandler(this.MainMenu_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
