﻿// Decompiled with JetBrains decompiler
// Type: NetChat.ClientForm
// Assembly: NetChat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B627D88F-BE10-4C48-8F82-411DE3984AB3
// Assembly location: C:\Users\janic\source\repos\Network Adventues\NetChat\bin\Debug\NetChat.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace NetChat
{
  public class ClientForm : Form
  {
    private TcpClient clientSocket = new TcpClient();
    private NetworkStream serverStream = (NetworkStream) null;
    private IContainer components = (IContainer) null;
    private string readData;
    private Thread ctThread;
    private TextBox chatHistory;
    private Label serverAddr;
    private Button connectButton;
    private TextBox userNameTextBox;
    private Button sendButton;
    private TextBox msgBox;
    private TextBox serverIPBox;

    public ClientForm()
    {
      this.InitializeComponent();
    }

    private void connectButton_Click(object sender, EventArgs e)
    {
      this.readData = "Connected to Chat Server ...";
      this.msg();
      this.clientSocket.Connect(this.serverIPBox.Text, 8888);
      this.serverStream = this.clientSocket.GetStream();
      byte[] bytes = Encoding.ASCII.GetBytes(this.userNameTextBox.Text + "$");
      this.serverStream.Write(bytes, 0, bytes.Length);
      this.serverStream.Flush();
      this.ctThread = new Thread(new ThreadStart(this.getMessage));
      this.ctThread.Start();
    }

    private void chatHistory_TextChanged(object sender, EventArgs e)
    {
      if (!this.chatHistory.Visible)
        return;
      this.chatHistory.SelectionStart = this.chatHistory.TextLength;
      this.chatHistory.ScrollToCaret();
      this.chatHistory.DeselectAll();
    }

    private void msgBox_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.Return)
        return;
      this.send();
    }

    private void sendButton_Click(object sender, EventArgs e)
    {
      this.send();
    }

    private void ClientForm_FormClosing(object sender, FormClosingEventArgs e)
    {
      this.ctThread.Abort();
    }

    private void send()
    {
      byte[] bytes = Encoding.ASCII.GetBytes(this.msgBox.Text + "$");
      this.serverStream.Write(bytes, 0, bytes.Length);
      this.serverStream.Flush();
      this.msgBox.Text = "";
    }

    private void getMessage()
    {
      while (true)
      {
        this.serverStream = this.clientSocket.GetStream();
        byte[] numArray = new byte[this.clientSocket.ReceiveBufferSize];
        int receiveBufferSize = this.clientSocket.ReceiveBufferSize;
        this.serverStream.Read(numArray, 0, receiveBufferSize);
        this.readData = Encoding.ASCII.GetString(numArray) ?? "";
        this.msg();
      }
    }

    private void msg()
    {
      if (this.InvokeRequired)
        this.Invoke((Delegate) new MethodInvoker(this.msg));
      else
        this.chatHistory.Text = this.chatHistory.Text + Environment.NewLine + " >> " + this.readData;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.chatHistory = new TextBox();
      this.serverAddr = new Label();
      this.connectButton = new Button();
      this.userNameTextBox = new TextBox();
      this.sendButton = new Button();
      this.msgBox = new TextBox();
      this.serverIPBox = new TextBox();
      this.SuspendLayout();
      this.chatHistory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.chatHistory.BackColor = Color.White;
      this.chatHistory.Cursor = Cursors.Hand;
      this.chatHistory.Location = new Point(12, 64);
      this.chatHistory.Multiline = true;
      this.chatHistory.Name = "chatHistory";
      this.chatHistory.ReadOnly = true;
      this.chatHistory.ScrollBars = ScrollBars.Both;
      this.chatHistory.Size = new Size(319, 244);
      this.chatHistory.TabIndex = 0;
      this.chatHistory.Text = "Press Connect to get started!";
      this.chatHistory.TextChanged += new EventHandler(this.chatHistory_TextChanged);
      this.serverAddr.AutoSize = true;
      this.serverAddr.Location = new Point(9, 14);
      this.serverAddr.Name = "serverAddr";
      this.serverAddr.Size = new Size(51, 13);
      this.serverAddr.TabIndex = 2;
      this.serverAddr.Text = "Server-IP";
      this.connectButton.Location = new Point(256, 8);
      this.connectButton.Name = "connectButton";
      this.connectButton.Size = new Size(75, 23);
      this.connectButton.TabIndex = 3;
      this.connectButton.Text = "Connect";
      this.connectButton.UseVisualStyleBackColor = true;
      this.connectButton.Click += new EventHandler(this.connectButton_Click);
      this.userNameTextBox.Location = new Point(67, 37);
      this.userNameTextBox.Name = "userNameTextBox";
      this.userNameTextBox.Size = new Size(183, 20);
      this.userNameTextBox.TabIndex = 4;
      this.sendButton.Location = new Point(256, 314);
      this.sendButton.Name = "sendButton";
      this.sendButton.Size = new Size(75, 23);
      this.sendButton.TabIndex = 5;
      this.sendButton.Text = "Send";
      this.sendButton.UseVisualStyleBackColor = true;
      this.sendButton.Click += new EventHandler(this.sendButton_Click);
      this.msgBox.Location = new Point(12, 314);
      this.msgBox.Name = "msgBox";
      this.msgBox.Size = new Size(238, 20);
      this.msgBox.TabIndex = 6;
      this.msgBox.KeyDown += new KeyEventHandler(this.msgBox_KeyDown);
      this.serverIPBox.Location = new Point(67, 11);
      this.serverIPBox.Name = "serverIPBox";
      this.serverIPBox.Size = new Size(183, 20);
      this.serverIPBox.TabIndex = 7;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.AutoValidate = AutoValidate.EnableAllowFocusChange;
      this.ClientSize = new Size(343, 360);
      this.Controls.Add((Control) this.serverIPBox);
      this.Controls.Add((Control) this.msgBox);
      this.Controls.Add((Control) this.sendButton);
      this.Controls.Add((Control) this.userNameTextBox);
      this.Controls.Add((Control) this.connectButton);
      this.Controls.Add((Control) this.serverAddr);
      this.Controls.Add((Control) this.chatHistory);
      this.Name = nameof (ClientForm);
      this.Text = nameof (ClientForm);
      this.FormClosing += new FormClosingEventHandler(this.ClientForm_FormClosing);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
