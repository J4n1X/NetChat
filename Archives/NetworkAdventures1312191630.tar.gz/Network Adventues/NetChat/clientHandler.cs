﻿// Decompiled with JetBrains decompiler
// Type: NetChat.clientHandler
// Assembly: NetChat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B627D88F-BE10-4C48-8F82-411DE3984AB3
// Assembly location: C:\Users\janic\source\repos\Network Adventues\NetChat\bin\Debug\NetChat.exe

using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace NetChat
{
  public class clientHandler
  {
    public static IDictionary<string, Thread> threadList = (IDictionary<string, Thread>) new Dictionary<string, Thread>();
    private TcpClient clientSocket;
    private string clNo;
    private IDictionary<string, TcpClient> clientsList;

    public void StartClientThread(
      TcpClient inClientSocket,
      string clineNo,
      IDictionary<string, TcpClient> cList)
    {
      this.clientSocket = inClientSocket;
      this.clNo = clineNo;
      this.clientsList = cList;
      Thread thread = new Thread(new ThreadStart(this.ClientCommunicator));
      clientHandler.threadList.Add(this.clNo, thread);
      thread.Start();
    }

    public void ClientCommunicator()
    {
      byte[] numArray = new byte[this.clientSocket.ReceiveBufferSize];
      NetworkStream stream = this.clientSocket.GetStream();
      Server server = new Server();
      while (true)
      {
        try
        {
          stream.Read(numArray, 0, numArray.Length);
          string msg = Encoding.ASCII.GetString(numArray).Split('$')[0];
          Server.Broadcast(msg, this.clNo, true, false);
          server.consoleList.Add("Message from Client - " + this.clNo + " " + msg);
        }
        catch (Exception ex)
        {
          server.consoleList.Add("Client " + this.clNo + " Disconnecting");
          Server.ClientRemove(this.clNo);
          break;
        }
      }
    }
  }
}
