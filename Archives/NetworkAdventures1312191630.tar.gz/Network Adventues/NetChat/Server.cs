﻿// Decompiled with JetBrains decompiler
// Type: NetChat.Server
// Assembly: NetChat, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: B627D88F-BE10-4C48-8F82-411DE3984AB3
// Assembly location: C:\Users\janic\source\repos\Network Adventues\NetChat\bin\Debug\NetChat.exe

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace NetChat
{
    internal class Server
    {
        private static IDictionary<string, TcpClient> ClientsList = (IDictionary<string, TcpClient>)new Dictionary<string, TcpClient>();
        private TcpClient clientSocket = (TcpClient)null;
        public Server.ConsoleList<string> consoleList = new Server.ConsoleList<string>();
        private IPAddress serverIp;
        private TcpListener serverSocket;

        public void serverLoader(string inp)
        {
            this.StartServer(inp);
            this.ClientAdd();
        }



        public void StartServer(string Ipaddr)
        {
            string ipString = Ipaddr;
            this.serverIp = !(ipString == "") ? IPAddress.Parse(ipString) : IPAddress.Parse("127.0.0.1");
            this.serverSocket = new TcpListener(this.serverIp, 8888);
            this.serverSocket.Start();
            this.consoleList.Add("Server successfully loaded!");
        }

        public void StopServer()
        {
        }

        public void ClientAdd()
        {
            while (true)
            {
                this.clientSocket = this.serverSocket.AcceptTcpClient();
                byte[] numArray = new byte[this.clientSocket.ReceiveBufferSize];
                this.clientSocket.GetStream().Read(numArray, 0, numArray.Length);
                string str1 = Encoding.ASCII.GetString(numArray);
                string str2 = str1.Substring(0, str1.IndexOf("$"));
                Server.ClientsList.Add(str2, this.clientSocket);
                new clientHandler().StartClientThread(this.clientSocket, str2, Server.ClientsList);
                Server.Broadcast(str2 + " Joined the Server", str2, false, false);
                this.consoleList.Add(str2 + " Joined the Server");
            }
        }

        public static void ClientRemove(string clNo)
        {
            foreach (KeyValuePair<string, Thread> thread in (IEnumerable<KeyValuePair<string, Thread>>)clientHandler.threadList)
            {
                if (clNo == thread.Key)
                    thread.Value.Abort();
            }
        }

        public static void Broadcast(string msg, string userName, bool dispName, bool sysReq)
        {
            foreach (KeyValuePair<string, TcpClient> clients in (IEnumerable<KeyValuePair<string, TcpClient>>)Server.ClientsList)
            {
                NetworkStream stream = clients.Value.GetStream();
                byte[] buffer = !dispName ? Encoding.ASCII.GetBytes(msg) : Encoding.ASCII.GetBytes(userName + " says: " + msg);
                stream.Write(buffer, 0, buffer.Length);
                stream.Flush();
            }
        }

        public class ConsoleList<T> : List<T>
        {
            public event EventHandler ListUpdate;

            public new void Add(T item)
            {
                EventHandler listUpdate = this.ListUpdate;
                if (listUpdate != null)
                    listUpdate((object)this, EventArgs.Empty);
                base.Add(item);
            }
        }
    }
}
