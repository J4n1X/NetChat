﻿using System;
using System.Threading;
using System.Net.Sockets;
using System.Text;

namespace Chat
{
    class Program
    {

        private string readdata; 
        static void Main(string[] args)
        {
            System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
            NetworkStream serverStream = default(NetworkStream);
            String start = Console.ReadLine();
            if(start == "1")
            {
                Server server = new Server();
                server.serverLoader();
            }
            else
            {
                clientSocket.Connect("127.0.0.1", 8888);
                serverStream = clientSocket.GetStream();

                byte[] outStream = System.Text.Encoding.ASCII.GetBytes("TestUser$");
                serverStream.Write(outStream, 0, outStream.Length);
                serverStream.Flush();
            }

            
            Console.Read();
        }

    }
}
